<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://wordpress.org/support/article/editing-wp-config-php/
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'wordpress' );

/** MySQL database username */
define( 'DB_USER', 'admin' );

/** MySQL database password */
define( 'DB_PASSWORD', 'awsconsole' );

/** MySQL hostname */
define( 'DB_HOST', 'database-1.c0si446hktkp.ap-south-1.rds.amazonaws.com' );

/** Database Charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8mb4' );

/** The Database Collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',         'f2s<yh:*wQuX)U1g[ seo[OX-3S_89QmC/HTD-5xy3)00w>-8A6~<X{z:UW%5Ic]' );
define( 'SECURE_AUTH_KEY',  'DIwwwN|(){=_QG1dL@lur$u8!%p^/~1RF1f2dEQ`+3t+S;Llk.)9f_sa`s2fn!iT' );
define( 'LOGGED_IN_KEY',    '* ,t6t|77ze#QgdT)AqF;.{5D?/qP}i:*tf4>-1t,ELS%fF)$$`G/6{&j>$t^7=?' );
define( 'NONCE_KEY',        'Pl09=EJgNsVqpCWj>L|3[lci,b8X_p0h7Stnp[OLZO!bDi?a5 6bywBpTY*~JPLe' );
define( 'AUTH_SALT',        'p ,hXwoCbM4M}]e{bnaQSa0dI-te|:hw=AM)5mh:l#}}P00L*o =u|a.h>rg<h?2' );
define( 'SECURE_AUTH_SALT', 'sV$/v&0WmuxOzXnZ+yKjG^eF9kVx9fsse(@__|%bF:=z$Em_`9rNtxI)c*ELeyYl' );
define( 'LOGGED_IN_SALT',   'fa@PC$z=Qd??Wm0GG~o,[0ojK3?,hdXkQRlUhT /&&~l8e3*^2Hxf{f(rG<~[ktw' );
define( 'NONCE_SALT',       'bs$Q.1QYt_vf3QB=1~OJdO&DIA<9;$7R1hooQC!R.(*3%b>D&|#`s<VPPcA{UUYs' );

/**#@-*/

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'wp_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the documentation.
 *
 * @link https://wordpress.org/support/article/debugging-in-wordpress/
 */
define( 'WP_DEBUG', false );

/* That's all, stop editing! Happy publishing. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', __DIR__ . '/' );
}

/** Sets up WordPress vars and included files. */
require_once ABSPATH . 'wp-settings.php';

